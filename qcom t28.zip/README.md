Dear friends, if you use our modification as a basis for further improvement, please, in order to respect the time spent by me and my team, indicate the authorship. 
This is not shameful, there is nothing shameful in it, but at the same time you express a sign of gratitude to those who voluntarily work on the creation of this modification. 
Thank you so much for your understanding.
