magiskpolicy --live "type vendor_file"
magiskpolicy --live "type vendor_configs_file"